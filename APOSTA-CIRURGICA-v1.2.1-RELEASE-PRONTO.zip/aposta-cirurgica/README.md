# APOSTA CIRÚRGICA — projeto consolidado v1.2

Esta versão combina a interface WebView, radar de eventos/odds, calculadora de valor esperado e histórico local do projeto Android principal com a calculadora 1X2 do projeto inicial.

## Recursos presentes
- Radar de eventos e odds via The Odds API, quando uma chave válida é configurada e o plano cobre as ligas/mercados solicitados.
- Filtros para NBA, futebol e mercados de resultado, totais e handicap.
- Calculadora de valor esperado (EV), odd justa e edge.
- Calculadora 1X2 com mandante/empate/visitante, odds justas, margem bruta e EV por resultado.
- Histórico local das análises no aparelho.
- WebView reforçado com AndroidX WebViewAssetLoader, bloqueio de acesso direto a arquivos/conteúdo, bloqueio de conteúdo misto e Safe Browsing ativo.

## Compilação e assinatura de lançamento
- Android Gradle Plugin 8.7.3
- AndroidX WebKit 1.12.1
- Kotlin 2.0.21
- JDK 17 / bytecode Java e Kotlin 17
- Gradle 8.9 no GitHub Actions
- Android SDK 35
- A variante `release` é não-debuggable e só é assinada quando os segredos de assinatura estão configurados.

Envie o arquivo `APOSTA-CIRURGICA-v1.2.1-RELEASE-PRONTO.zip` para a raiz do repositório GitHub e faça o commit. O workflow reconhece esse nome e extrai o projeto automaticamente. Ele sempre gera `APOSTA-CIRURGICA-debug-TESTE`. Para gerar também `APOSTA-CIRURGICA-RELEASE`, configure os quatro segredos abaixo no GitHub antes de executar o workflow.

### Criar a chave privada no próprio celular (Termux)
1. Instale o Termux de uma fonte confiável, como F-Droid, e abra-o.
2. Execute `pkg update && pkg install openjdk-17 coreutils`.
3. Gere uma chave de assinatura: `keytool -genkeypair -v -keystore aposta-cirurgica-release.jks -alias aposta-cirurgica -keyalg RSA -keysize 4096 -validity 10000`.
4. Defina senhas fortes quando solicitado e guarde o arquivo `.jks` e as senhas em local seguro. **Nunca envie a chave ou as senhas no chat nem as coloque no repositório.**
5. Gere o texto Base64 com `base64 -w 0 aposta-cirurgica-release.jks` e copie a saída completa.
6. No GitHub, abra o repositório → Settings → Secrets and variables → Actions → New repository secret. Crie estes quatro segredos:
   - `ANDROID_KEYSTORE_BASE64`: saída completa do comando Base64.
   - `ANDROID_KEYSTORE_PASSWORD`: senha do arquivo keystore.
   - `ANDROID_KEY_ALIAS`: `aposta-cirurgica`.
   - `ANDROID_KEY_PASSWORD`: senha da chave (pode ser a mesma, se assim escolheu).
7. Execute Actions → `Gerar APK Android` → Run workflow. Baixe o artefato `APOSTA-CIRURGICA-RELEASE` quando aparecer.

**Muito importante:** mantenha cópias seguras do arquivo `.jks` e das senhas. Atualizações futuras precisam usar exatamente a mesma chave; se ela for perdida, não será possível atualizar uma instalação assinada com ela pelo fluxo normal.

## Configuração de dados
A consulta de odds requer uma chave The Odds API fornecida pelo usuário. A chave é armazenada no armazenamento local do app e as consultas são manuais. Não inclua chaves no GitHub nem compartilhe um APK com chave pessoal salva. Para distribuição pública, use um backend intermediário para proteger credenciais.

## Segurança e distribuição
- A variante debug é somente para testes. A variante release é compilada com `debuggable false` e assinatura privada configurada pelo proprietário do repositório. Uma assinatura própria não garante que o Google Play Protect deixe de alertar ou bloquear um app instalado fora da Play Store. Não desative o Play Protect para instalar. Se ele continuar bloqueando, investigue a detecção e considere distribuição pela Play Store após cumprir os requisitos aplicáveis.
- A chave da The Odds API é armazenada localmente no app e enviada ao provedor nas consultas. Para distribuição pública, mova a consulta para um backend próprio e nunca inclua credenciais no APK.

## Limitações
Lesões, escalações, suspensões e resultados históricos ainda não possuem integração nesta versão. Não há previsões automáticas garantidas: as calculadoras avaliam probabilidades informadas pelo usuário. A disponibilidade de eventos e mercados depende do provedor e do plano contratado.
