# APOSTA CIRÚRGICA — projeto consolidado v1.2

Esta versão combina a interface WebView, radar de eventos/odds, calculadora de valor esperado e histórico local do projeto Android principal com a calculadora 1X2 do projeto inicial.

## Recursos presentes
- Radar de eventos e odds via The Odds API, quando uma chave válida é configurada e o plano cobre as ligas/mercados solicitados.
- Filtros para NBA, futebol e mercados de resultado, totais e handicap.
- Calculadora de valor esperado (EV), odd justa e edge.
- Calculadora 1X2 com mandante/empate/visitante, odds justas, margem bruta e EV por resultado.
- Histórico local das análises no aparelho.
- WebView reforçado com AndroidX WebViewAssetLoader, bloqueio de acesso direto a arquivos/conteúdo, bloqueio de conteúdo misto e Safe Browsing ativo.

## Compilação
- Android Gradle Plugin 8.7.3
- AndroidX WebKit 1.12.1
- Kotlin 2.0.21
- JDK 17 / bytecode Java e Kotlin 17
- Gradle 8.9 no GitHub Actions
- Android SDK 35

Envie o conteúdo da pasta `aposta-cirurgica` para a raiz do repositório GitHub (não envie a pasta externa como subpasta). O workflow executa em `main` ou `principal`. Abra Actions, selecione `Gerar APK Android`, aguarde o job e baixe o artefato `APOSTA-CIRURGICA-debug`.

## Configuração de dados
A consulta de odds requer uma chave The Odds API fornecida pelo usuário. A chave é armazenada no armazenamento local do app e as consultas são manuais. Não inclua chaves no GitHub nem compartilhe um APK com chave pessoal salva. Para distribuição pública, use um backend intermediário para proteger credenciais.

## Segurança e distribuição
- Esta versão continua sendo compilada como APK de depuração para teste privado. O alerta do Google Play Protect pode ocorrer com aplicativos sideloaded e não é possível garantir que a mudança o elimine. Não desative o Play Protect para instalar.
- A chave da The Odds API é armazenada localmente no app e enviada ao provedor nas consultas. Para distribuição pública, mova a consulta para um backend próprio e nunca inclua credenciais no APK.

## Limitações
Lesões, escalações, suspensões e resultados históricos ainda não possuem integração nesta versão. Não há previsões automáticas garantidas: as calculadoras avaliam probabilidades informadas pelo usuário. A disponibilidade de eventos e mercados depende do provedor e do plano contratado.
