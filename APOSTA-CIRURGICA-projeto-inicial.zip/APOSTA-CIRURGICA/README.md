# APOSTA CIRÚRGICA

Aplicativo Android inicial para análise de apostas esportivas.

## Recursos nesta primeira compilação
- Calculadora 1X2 com probabilidades estimadas.
- Odds justas.
- EV (valor esperado) por resultado.
- Estimativa simples da margem do mercado.
- Interface Android nativa.

## Gerar APK pelo GitHub
1. Envie todos os arquivos e pastas deste projeto para a raiz do repositório.
2. Confirme o commit na branch `principal` (ou `main`).
3. Abra a aba **Actions** do GitHub.
4. Entre em **Build Android APK** e aguarde o workflow concluir.
5. Abra a execução concluída e baixe o artefato `APOSTA-CIRURGICA-debug`.
6. Extraia o ZIP do artefato e instale `app-debug.apk` no Android.

## Limitações importantes
Esta versão não consulta odds, resultados ou escalações em tempo real. Para dados ao vivo é necessário escolher e configurar um provedor/API e sua chave privada. Não publique chaves de API no repositório. O app ainda é uma base funcional inicial, não a versão completa prometida com integração de dados, histórico persistente e todos os mercados.

## Ambiente de compilação
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- JDK 17
- Android SDK 35
