package br.com.apostacirurgica

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 23, 34)
    private val panel = Color.rgb(27, 38, 53)
    private val mint = Color.rgb(24, 201, 139)
    private lateinit var pHome: EditText
    private lateinit var pDraw: EditText
    private lateinit var pAway: EditText
    private lateinit var oHome: EditText
    private lateinit var oDraw: EditText
    private lateinit var oAway: EditText
    private lateinit var result: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 32)
        }
        scroll.addView(layout)
        layout.addView(label("APOSTA CIRÚRGICA", 27, mint, true))
        layout.addView(label("ANÁLISE ESPORTIVA • FUTEBOL & NBA", 12, Color.LTGRAY, true))
        layout.addView(space(18))
        layout.addView(card("Calculadora 1X2 e Value Bet"))
        layout.addView(label("Insira suas probabilidades estimadas (%)", 14, Color.WHITE, true))
        pHome = field("Probabilidade mandante (ex.: 50)")
        pDraw = field("Probabilidade empate (ex.: 27)")
        pAway = field("Probabilidade visitante (ex.: 23)")
        layout.addView(pHome); layout.addView(pDraw); layout.addView(pAway)
        layout.addView(space(10))
        layout.addView(label("Insira as odds decimais disponíveis", 14, Color.WHITE, true))
        oHome = field("Odd mandante (ex.: 2.00)")
        oDraw = field("Odd empate (ex.: 3.40)")
        oAway = field("Odd visitante (ex.: 4.00)")
        layout.addView(oHome); layout.addView(oDraw); layout.addView(oAway)
        val calc = Button(this).apply {
            text = "CALCULAR ANÁLISE"
            setTextColor(Color.BLACK)
            setBackgroundColor(mint)
            textSize = 16f
            setOnClickListener { calculate() }
        }
        layout.addView(calc, params())
        result = label("O resultado da análise aparecerá aqui.", 15, Color.WHITE, false)
        result.setPadding(14, 18, 14, 18)
        result.setBackgroundColor(panel)
        layout.addView(result, params())
        layout.addView(space(18))
        layout.addView(card("Gestão de banca • Kelly fracionado"))
        layout.addView(label("A versão inicial oferece cálculo de probabilidades, odds justas, margem e valor esperado (EV). O registro de apostas e integração com provedores de dados serão adicionados nas próximas etapas.", 14, Color.LTGRAY, false))
        layout.addView(space(14))
        layout.addView(label("Aviso: ferramenta analítica, não garantia de resultado. Aposte com responsabilidade e nunca arrisque dinheiro que não pode perder.", 12, Color.LTGRAY, false))
        setContentView(scroll)
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 5, 0, 5)
        }

    private fun field(hintText: String) = EditText(this).apply {
        hint = hintText
        setHintTextColor(Color.LTGRAY)
        setTextColor(Color.WHITE)
        textSize = 15f
        inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        setSingleLine(true)
        setPadding(14, 8, 14, 8)
        setBackgroundColor(panel)
        val lp = params()
        lp.bottomMargin = 8
        layoutParams = lp
    }

    private fun card(text: String) = label(text, 18, mint, true).apply {
        setPadding(14, 14, 14, 14)
        setBackgroundColor(panel)
    }

    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, h) }
    private fun params() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 12 }

    private fun number(e: EditText): Double? = e.text.toString().trim().replace(",", ".").toDoubleOrNull()

    private fun calculate() {
        val probs = listOf(number(pHome), number(pDraw), number(pAway))
        val odds = listOf(number(oHome), number(oDraw), number(oAway))
        if (probs.any { it == null } || odds.any { it == null } ||
            probs.any { it!! < 0.0 || it > 100.0 } || odds.any { it!! <= 1.0 }) {
            result.text = "Preencha todos os campos. Probabilidades entre 0 e 100; odds maiores que 1.00."
            return
        }
        val ps = probs.map { it!! / 100.0 }
        val os = odds.map { it!! }
        val sum = ps.sum()
        if (kotlin.math.abs(sum - 1.0) > 0.015) {
            result.text = "A soma das probabilidades deve ser 100%. Soma atual: %.1f%%".format(sum * 100)
            return
        }
        val labels = listOf("Mandante", "Empate", "Visitante")
        val lines = labels.indices.map { i ->
            val fair = 1.0 / ps[i]
            val ev = ps[i] * os[i] - 1.0
            val status = if (ev > 0.0) "POTENCIAL VALUE" else "SEM VALOR"
            "${labels[i]}: prob. %.1f%% | odd justa %.2f | EV %.1f%% | %s".format(ps[i] * 100, fair, ev * 100, status)
        }
        val implied = os.sumOf { 1.0 / it }
        result.text = "ANÁLISE 1X2\nMargem bruta estimada do mercado: %.1f%%\n\n%s".format((implied - 1) * 100, lines.joinToString("\n\n"))
    }
}
